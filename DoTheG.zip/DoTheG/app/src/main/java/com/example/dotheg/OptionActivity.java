package com.example.dotheg;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class OptionActivity extends AppCompatActivity {

    Button changeBGMButton1;
    Button changeBGMButton2;

    Button turnOn;
    Button turnOff;

    Button easyLevel;
    Button normalLevel;
    Button hardLevel;
    Button challengeLevel;

    SeekBar backgroundSeek;
    SeekBar effectSeek;

    TextView currentLevel;

    MediaPlayer bgm1;
    MediaPlayer bgm2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_option);

        currentLevel = findViewById(R.id.currentLevel);

        changeBGMButton1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                currentLevel.setText("abcd");
                currentLevel.append("abcd");

            }
        });
        changeBGMButton2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
            }

        });

        //bgm1 = MediaPlayer.create(this, R.raw.sample1);
        //bgm2 = MediaPlayer.create(OptionActivity.this, R.raw.sample2);

        //bgm1.start();
        //bgm2.start();
        //bgm1 =

    }
}