package com.example.dotheg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public MediaPlayer bgm1;
    public MediaPlayer bgm2;
    MediaPlayer hit;
    public int whatisplaying;
    public int difficultyLevel;


    Button changeBGMButton1;
    Button changeBGMButton2;

    Button turnOn;
    Button turnOff;

    Button easyLevel;
    Button normalLevel;
    Button hardLevel;
    Button challengeLevel;

    SeekBar backgroundSeek;
    SeekBar effectSeek;

    TextView currentLevel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button startButton = findViewById(R.id.starting);
        Button helpButton = findViewById(R.id.helping);
        Button settingButton = findViewById(R.id.setting);

        changeBGMButton1 = findViewById(R.id.changeBGM1);
        changeBGMButton2 = findViewById(R.id.changeBGM2);

        currentLevel = findViewById(R.id.currentLevel);

        bgm1 = MediaPlayer.create(MainActivity.this, R.raw.sample1);
        bgm2 = MediaPlayer.create(MainActivity.this, R.raw.sample2);

        hit = MediaPlayer.create(MainActivity.this, R.raw.hit);


        ///1
        startButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), PlayActivity.class);
                startActivity(intent);
            }
        });


        ///2
        helpButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), HelpActivity.class);
                startActivity(intent);
            }
        });

        ///3
        settingButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){


                setContentView(R.layout.activity_option);

                // 노래 변경 가능 여부 확인
                /*
                if(whatisplaying == 1){
                    bgm1.pause();
                    bgm1.seekTo(0);
                    bgm2.start();

                    whatisplaying = 2;
                }
                else{
                    bgm2.pause();
                    bgm2.seekTo(0);
                    bgm1.start();

                    whatisplaying = 1;
                }
                */

            }
        });

        /*

        changeBGMButton1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

                if(whatisplaying == 2){

                    bgm2.pause();
                    bgm2.seekTo(0);
                    bgm1.start();

                    whatisplaying = 1;
                }
            }
        });
        changeBGMButton2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

                if(whatisplaying == 1){

                    bgm1.pause();
                    bgm1.seekTo(0);
                    bgm2.start();

                    whatisplaying = 2;
                }
            }

        });

        */

        bgm1.start();
        whatisplaying = 1;

        //점수저장
        //
        //back 버튼 누를 시 점수 초기화
        //
        //help 내용 채우기
        //
        //게임 구현


    }
}