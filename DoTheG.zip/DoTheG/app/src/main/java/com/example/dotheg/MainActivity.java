package com.example.dotheg;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public MediaPlayer bgm1;
    public MediaPlayer bgm2;
    MediaPlayer hit;
    boolean isturnon;
    int whatisplaying;
    int difficultyLevel;

    float BackgroundSoundValue;
    float effectSoundValue;

    Button changeBGMButton1;
    Button changeBGMButton2;
    Button turnOn;
    Button turnOff;

    Button easyLevel;
    Button normalLevel;
    Button hardLevel;
    Button challengeLevel;

    SeekBar backgroundSeek;
    SeekBar effectSeek;

    TextView currentLevel;

    ConstraintLayout optionLayout;
    Button optionDoneButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button startButton = findViewById(R.id.starting);
        final Button helpButton = findViewById(R.id.helping);
        final Button settingButton = findViewById(R.id.setting);

        isturnon = true;

        changeBGMButton1 = findViewById(R.id.changeBGM1);
        changeBGMButton2 = findViewById(R.id.changeBGM2);
        turnOn = findViewById(R.id.turnOn);
        turnOff = findViewById(R.id.turnOff);

        easyLevel = findViewById(R.id.easy);
        normalLevel = findViewById(R.id.normal);
        hardLevel = findViewById(R.id.hard);
        challengeLevel = findViewById(R.id.challenge);

        BackgroundSoundValue = 0.6f;
        effectSoundValue = 0.6f;

        backgroundSeek = findViewById(R.id.backgroundSeek);
        effectSeek = findViewById(R.id.effectSeek);

        currentLevel = findViewById(R.id.currentLevel);

        bgm1 = MediaPlayer.create(MainActivity.this, R.raw.sample1);
        bgm2 = MediaPlayer.create(MainActivity.this, R.raw.sample2);

        hit = MediaPlayer.create(MainActivity.this, R.raw.hit);

        optionLayout = findViewById(R.id.optionLayout);
        optionDoneButton = findViewById(R.id.optionDone);

        ///1
        startButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), PlayActivity.class);
                intent.putExtra("Difficulty", difficultyLevel);
                intent.putExtra("EffectVolume", effectSoundValue);
                startActivity(intent);
            }
        });


        ///2
        helpButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), HelpActivity.class);
                startActivity(intent);
            }
        });

        ///3
        settingButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                changeLevelText();
                optionLayout.setVisibility(View.VISIBLE);
                startButton.setVisibility(View.GONE);
                helpButton.setVisibility(View.GONE);
                settingButton.setVisibility(View.GONE);
            }
        });

        optionDoneButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                optionLayout.setVisibility(View.GONE);
                startButton.setVisibility(View.VISIBLE);
                helpButton.setVisibility(View.VISIBLE);
                settingButton.setVisibility(View.VISIBLE);
            }
        });


        bgm1.setVolume(BackgroundSoundValue,BackgroundSoundValue);
        bgm2.setVolume(BackgroundSoundValue,BackgroundSoundValue);
        bgm1.start();
        whatisplaying = 1;
        difficultyLevel = 1;
        //currentLevel.setText("쉬움");
        //currentLevel.setTextColor(0x69FF5E);

        changeBGMButton1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if (whatisplaying == 2){
                    bgm2.pause();
                    bgm2.seekTo(0);
                    if(isturnon)
                        bgm1.start();
                    whatisplaying = 1;
                }
            }
        });
        changeBGMButton2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if (whatisplaying == 1){
                    bgm1.pause();
                    bgm1.seekTo(0);
                    if(isturnon)
                        bgm2.start();
                    whatisplaying = 2;
                }
            }
        });

        turnOff.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if(isturnon){
                    if(whatisplaying == 1){
                        bgm1.pause();
                        bgm1.seekTo(0);
                    }
                    else{
                        bgm2.pause();
                        bgm2.seekTo(0);
                    }
                    isturnon = !isturnon;
                }
            }
        });

        turnOn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if(!isturnon){
                    if(whatisplaying == 1)
                        bgm1.start();
                    else
                        bgm2.start();
                    isturnon = !isturnon;
                }
            }
        });



        backgroundSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser){
                if(fromUser){
                    BackgroundSoundValue = ((float) progress) / 50;
                    bgm1.setVolume(BackgroundSoundValue,BackgroundSoundValue);
                    bgm2.setVolume(BackgroundSoundValue,BackgroundSoundValue);
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        effectSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser){
                if(fromUser){
                    effectSoundValue = ((float) progress) / 50;
                    hit.setVolume(effectSoundValue,effectSoundValue);
                    hit.start();
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        easyLevel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                difficultyLevel = 1;
                changeLevelText();
                Log.i("Level", "Easy");
            }
        });

        normalLevel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                difficultyLevel = 2;
                changeLevelText();
                Log.i("Level", "Normal");
            }
        });

        hardLevel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                difficultyLevel = 3;
                changeLevelText();
                Log.i("Level", "Hard");
            }
        });

        challengeLevel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                difficultyLevel = 4;
                changeLevelText();
                Log.i("Level", "Challenge");
            }
        });
    }

    public void changeLevelText(){
        if (difficultyLevel == 1){
            currentLevel.setText("쉬움");
            currentLevel.setTextColor(0xFF69FF5E);
        }
        if (difficultyLevel == 2){
            currentLevel.setText("보통");
            currentLevel.setTextColor(0xFF8880FF);
        }
        if (difficultyLevel == 3){
            currentLevel.setText("어려움");
            currentLevel.setTextColor(0xFFD06CEC);
        }
        if (difficultyLevel == 4){
            currentLevel.setText("도전");
            currentLevel.setTextColor(0xFFE83F3F);
        }
    }
}