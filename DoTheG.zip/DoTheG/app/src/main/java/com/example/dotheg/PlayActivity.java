package com.example.dotheg;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class PlayActivity extends AppCompatActivity {
    ArrayList<MovingButton> buttons;
    int screenWidth, screenHeight;

    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);

        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        screenWidth = size.x; screenHeight = size.y;

        buttons = new ArrayList<>();

        buttons.add(new MovingButton( (ImageButton)findViewById(R.id.Hole1), screenWidth, screenHeight ) );
        buttons.add(new MovingButton( (ImageButton)findViewById(R.id.Hole2), screenWidth, screenHeight ) );

        foo();
    }

    public void foo(){
        new Timer().scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                for (MovingButton button : buttons){
                    button.move();
                }
            }
        }, 0, 33);
    }
}