package com.example.dotheg;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Point;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class PlayActivity extends AppCompatActivity {
    final String ScoreFilePath = "/Score.txt";

    ArrayList<MovingButton> buttons;
    CBRlong[] highScores = new CBRlong[10];
    int screenWidth, screenHeight;
    double timeLeft;
    boolean needInit;
    CBRboolean gameRunning;
    CBRdouble score;
    CBRint timeClickCount;
    CBRint difficulty;
    MediaPlayer effectSound1, effectSound2, effectSound3, effectSound4, effectSound5, effectSound6;
    CBRfloat effectVolume;

    Handler changeTextHandler, showTextHandler;

    TextView scoreView, timeView, timesupView, highscoreView;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);

        difficulty = new CBRint( getIntent().getIntExtra("Difficulty", 0) );
        effectVolume = new CBRfloat( getIntent().getFloatExtra("EffectVolume", 0.0f) );

        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        screenWidth = size.x; screenHeight = size.y;

        scoreView = findViewById(R.id.score);
        timeView = findViewById(R.id.time);
        timesupView = findViewById(R.id.timesup);
        highscoreView = findViewById(R.id.highscore);
        progressBar = findViewById(R.id.timeBar);

        changeTextHandler = new Handler(){
            public void handleMessage(Message msg){
                changeText(timeView, Integer.toString( (int)( timeLeft ) ));
                changeText(scoreView, "점수 : " + Long.toString( (long)( score.getVal() ) ));
                changeText(highscoreView, "최고점 : " + Long.toString( (long)( highScores[difficulty.getVal()].getVal() ) ));
            }
        };
        showTextHandler = new Handler(){
            public void handleMessage(Message msg){
                showText(timesupView);
            }
        };

        score = new CBRdouble(0);
        timeLeft = 60.0;
        needInit = true;
        gameRunning = new CBRboolean(true);
        timeClickCount = new CBRint(0);

        ReadFile();

        effectSound1 = MediaPlayer.create(PlayActivity.this, R.raw.hit);
        effectSound2 = MediaPlayer.create(PlayActivity.this, R.raw.hit);
        effectSound3 = MediaPlayer.create(PlayActivity.this, R.raw.hit);
        effectSound4 = MediaPlayer.create(PlayActivity.this, R.raw.hit);
        effectSound5 = MediaPlayer.create(PlayActivity.this, R.raw.hit);
        effectSound6 = MediaPlayer.create(PlayActivity.this, R.raw.hit);

        buttons = new ArrayList<>();

        buttons.add(new MovingButton( (ImageButton)findViewById(R.id.Hole1), (ImageButton)findViewById(R.id.Hole), screenWidth, screenHeight, score, gameRunning, difficulty, effectSound1, effectVolume ) );
        buttons.add(new MovingButton( (ImageButton)findViewById(R.id.Hole2), (ImageButton)findViewById(R.id.Hole), screenWidth, screenHeight, score, gameRunning, difficulty, effectSound2, effectVolume ) );
        buttons.add(new MovingButton( (ImageButton)findViewById(R.id.Hole3), (ImageButton)findViewById(R.id.Hole), screenWidth, screenHeight, score, gameRunning, difficulty, effectSound3, effectVolume ) );
        buttons.add(new MovingButton( (ImageButton)findViewById(R.id.Hole4), (ImageButton)findViewById(R.id.Hole), screenWidth, screenHeight, score, gameRunning, difficulty, effectSound4, effectVolume ) );
        buttons.add(new MovingButton( (ImageButton)findViewById(R.id.Hole5), (ImageButton)findViewById(R.id.Hole), screenWidth, screenHeight, score, gameRunning, difficulty, effectSound5, effectVolume ) );
        buttons.add(new MovingButton( (ImageButton)findViewById(R.id.Hole6), (ImageButton)findViewById(R.id.Hole), screenWidth, screenHeight, score, gameRunning, difficulty, effectSound6, effectVolume ) );

        progressBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timeClickCount.addVal(1);
                if (timeClickCount.getVal() >= 20){
                    timeClickCount.setVal(0);
                    timeLeft += 1.0;
                }
            }
        });

        final Timer timeTimer = new Timer();
        final Timer textTimer = new Timer();
        final Timer directionTimer = new Timer();
        final Timer holeTimer = new Timer();

        final TimerTask showText = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Message msg = changeTextHandler.obtainMessage();
                        changeTextHandler.sendMessage(msg);
                    }
                });
            }
        };

        final TimerTask moveHole = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        for (MovingButton button : buttons){
                            if (needInit) button.initXY();
                            button.move();
                        }
                        needInit = false;
                    }
                });
            }
        };

        final TimerTask changeDirection = new TimerTask() {
            @Override
            public void run() {
                for (MovingButton button : buttons){
                    button.angle = Math.random() * 360;
                }
                // Log.d("changeDirectionBOJ", "Change Direction");
            }
        };

        final TimerTask timePass = new TimerTask(){
            @Override
            public void run() {
                timeLeft -= 1 / 30.0;
                progressBar.setProgress( (int)( timeLeft  * 1000 ) );
                if (timeLeft < 0){
                    timeTimer.cancel();
                    textTimer.cancel();
                    directionTimer.cancel();
                    holeTimer.cancel();
                    endGame();
                }
                else{
                    for (MovingButton button : buttons){
                        if (button.isMole == false){
                            button.waitTime -= 1 / 30.0;
                            if (button.waitTime <= 0){
                                button.MoleUp();
                            }
                        }
                        else{
                            button.showTime -= 1 / 30.0;
                            if (button.showTime <= 0){
                                button.MoleDown();
                            }
                        }
                    }
                }
            }
        };

        timeTimer.schedule(timePass, 0, 33);
        textTimer.schedule(showText, 0, 33);
        directionTimer.schedule(changeDirection, 10000, 10000);
        holeTimer.schedule(moveHole, 10000, 33);
    }

    public void endGame(){
        for (MovingButton button : buttons){
            button.MoleDown();
            // button.returnToStart();
        }
        gameRunning.setVal(false);
        Message msg = showTextHandler.obtainMessage();
        showTextHandler.sendMessage(msg);
        if (highScores[difficulty.getVal()].getVal() < (long)(score.getVal())){
            highScores[difficulty.getVal()].setVal( (long)(score.getVal()) );
        }
        WriteFile();
    }

    public void changeText(TextView textView, String string){
        textView.setText(string);
    }

    public void showText(TextView textView){
        textView.setVisibility(View.VISIBLE);
    }

    public void WriteFile(){
        File file = new File(getFilesDir() + ScoreFilePath);
        try{
            if (!file.exists()){
                file.getParentFile().mkdirs();
                file.createNewFile();
            }
        }
        catch (Exception e){
            Log.i("WriteFileException", e.toString());
        }

        FileWriter fileWriter = null;
        try{
            fileWriter = new FileWriter(file);
            for (int i = 0; i < 10; i++){
                fileWriter.write( highScores[i].getVal() + "\n" );
            }
        }
        catch (Exception e){
            Log.i("WriteFileException", e.toString());
        }
        if (fileWriter != null){
            try{
                fileWriter.close();
            }
            catch (Exception e){
                Log.i("WriteFileException", e.toString());
            }
        }

        Log.i("WriteFile", "File Writed");
    }

    public void ReadFile(){
        for (int i = 0; i < 10; i++){
            highScores[i] = new CBRlong(0);
        }

        File file = new File(getFilesDir() + ScoreFilePath);
        try{
            if (!file.exists()){
                file.getParentFile().mkdirs();
                file.createNewFile();
            }
        }
        catch (Exception e){
            Log.i("ReadFileException", e.toString());
        }

        FileReader fileReader = null;
        long highScore = 0;
        int index = 0;
        try{
            fileReader = new FileReader(file);
            while (true){
                int data = fileReader.read();
                if (data == -1) break;
                char ch = (char)data;
                Log.i("ReadFileCH", ch + "");
                if (ch == '\n'){
                    highScores[index] = new CBRlong( highScore );
                    index += 1;
                    highScore = 0;
                }
                else{
                    highScore = highScore*10 + ch-'0';
                }
            }
            Log.i("ReadFileSuccess", "YAY");
        }
        catch (Exception e){
            Log.i("ReadFileException", e.toString());
        }
        for (int i = 0; i < 10; i++){
            Log.i("ReadFileResult", highScores[i].getVal() + "");
        }
        Log.i("Show", "Me");
    }
}