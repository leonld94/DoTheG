package com.example.dotheg;

public class CBRfloat {
    float val;

    public CBRfloat(){
        this.val = 0.0f;
    }
    public CBRfloat(float val) {
        this.val = val;
    }

    public float getVal() {
        return val;
    }
    public void setVal(float val) {
        this.val = val;
    }
    public void addVal(float val2){
        this.val += val2;
    }
    public void addVal(CBRfloat val2){
        this.val += val2.getVal();
    }
}