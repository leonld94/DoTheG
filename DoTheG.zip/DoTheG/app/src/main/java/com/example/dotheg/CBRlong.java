package com.example.dotheg;

public class CBRlong {
    long val;

    public CBRlong() {
        this.val = 0;
    }
    public CBRlong(long val) {
        this.val = val;
    }

    public long getVal() {
        return val;
    }
    public void setVal(long val) {
        this.val = val;
    }
    public void addVal(long val2){
        this.val += val2;
    }
    public void addVal(CBRlong val2){
        this.val += val2.getVal();
    }
}
