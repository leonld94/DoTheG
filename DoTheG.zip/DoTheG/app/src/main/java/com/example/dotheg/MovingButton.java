package com.example.dotheg;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MovingButton {
    ImageButton button;
    double x, y, dx, dy;
    int screenWidth, screenHeight;

    public MovingButton(ImageButton button, int width, int height){
        this.button = button;
        this.screenWidth = width;
        this.screenHeight = height;
        x = y = 0;
        dx = Math.random() * 10 - 5;
        dy = Math.random() * 10 - 5;

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dx *= 0.9;
                dy *= 0.9;
            }
        });
    }

    public boolean collideX(){ return 0 > x || x + button.getWidth() > screenWidth; }
    public boolean collideY(){ return 0 > y || y + button.getHeight() > screenHeight; }

    public void move(){
        x += dx;
        y += dy;
        if (this.collideX()) dx *= -1;
        if (this.collideY()) dy *= -1;
        button.setX((float)x);
        button.setY((float)y);
        dx *= 1.01;
        dy *= 1.01;
        //button.setText(x + " " + y);
    }
}
