package com.example.dotheg;

public class CBRint {
    int val;

    public CBRint() {
        this.val = 0;
    }
    public CBRint(int val) {
        this.val = val;
    }

    public int getVal() {
        return val;
    }
    public void setVal(int val) {
        this.val = val;
    }
    public void addVal(int val2){
        this.val += val2;
    }
    public void addVal(CBRint val2){
        this.val += val2.getVal();
    }
}
