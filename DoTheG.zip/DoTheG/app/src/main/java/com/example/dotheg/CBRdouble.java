package com.example.dotheg;

public class CBRdouble {
    double val;

    public CBRdouble(){
        this.val = 0.0;
    }
    public CBRdouble(double val) {
        this.val = val;
    }

    public double getVal() {
        return val;
    }
    public void setVal(double val) {
        this.val = val;
    }
    public void addVal(double val2){
        this.val += val2;
    }
    public void addVal(CBRdouble val2){
        this.val += val2.getVal();
    }
}