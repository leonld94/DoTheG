package com.example.dotheg;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.widget.TextView;

public class HelpActivity extends AppCompatActivity {

    ViewPager pager;
    TextView TV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        pager = findViewById(R.id.pager);

        HelpAdapter adapter = new HelpAdapter(getSupportFragmentManager());

        TestFragment Fragment_1 = new TestFragment("1");
        adapter.addItem(Fragment_1);


        //Display display = getWindowManager().getDefaultDisplay();
        //Point size = new Point();
        //display.getSize(size);
        //int screenWidth, screenHeight;
        //screenWidth = size.x; screenHeight = size.y;

        //TV = findViewById(R.id.text1);

        //TV.setY(screenHeight-40);

        //TestFragment Fragment_2 = new TestFragment("2");
        //adapter.addItem(Fragment_2);

        //TestFragment Fragment_3 = new TestFragment("3");
        //adapter.addItem(Fragment_3);

        pager.setAdapter(adapter);
    }
}