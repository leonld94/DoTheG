package com.example.dotheg;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

public class HelpActivity extends AppCompatActivity {

    ViewPager pager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        pager = findViewById(R.id.pager);

        HelpAdapter adapter = new HelpAdapter(getSupportFragmentManager());

        TestFragment Fragment_1 = new TestFragment("1");
        adapter.addItem(Fragment_1);

        TestFragment Fragment_2 = new TestFragment("2");
        adapter.addItem(Fragment_2);

        TestFragment Fragment_3 = new TestFragment("3");
        adapter.addItem(Fragment_3);

        pager.setAdapter(adapter);
    }
}