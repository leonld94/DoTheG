package com.example.dotheg;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.widget.TextView;

public class HelpActivity extends AppCompatActivity {

    ViewPager pager;
    TextView TV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        pager = findViewById(R.id.pager);

        HelpAdapter adapter = new HelpAdapter(getSupportFragmentManager());

        TestFragment Fragment_1 = new TestFragment("1");
        adapter.addItem(Fragment_1);

        pager.setAdapter(adapter);
    }
}