package com.example.dotheg;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

public class HelpActivity extends AppCompatActivity {

    ViewPager pager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        pager = findViewById(R.id.pager);

        HelpAdapter adapter = new HelpAdapter(getSupportFragmentManager());

        TestFragment Fragment_1 = new TestFragment("너무 길어요");
        adapter.addItem(Fragment_1);

        TestFragment Fragment_2 = new TestFragment("다수결로 정하죠");
        adapter.addItem(Fragment_2);

        TestFragment Fragment_3 = new TestFragment("저작권료는 대간이가 내는 걸로 합의하죠. [Checked] [4$]");
        adapter.addItem(Fragment_3);

        pager.setAdapter(adapter);
    }
}