package com.example.dotheg;

public class CBRboolean {
    boolean val;

    public CBRboolean(){
        this.val = false;
    }
    public CBRboolean(boolean val) {
        this.val = val;
    }

    public boolean getVal() {
        return val;
    }
    public void setVal(boolean val) {
        this.val = val;
    }
}