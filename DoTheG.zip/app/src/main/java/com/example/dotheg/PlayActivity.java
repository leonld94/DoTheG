package com.example.dotheg;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class PlayActivity extends AppCompatActivity {
    ArrayList<MovingButton> buttons;
    int screenWidth, screenHeight;
    double timeLeft;
    boolean needInit;
    CBRboolean gameRunning;
    CBRdouble score;
    CBRint timeClickCount;
    Handler changeTextHandler, showTextHandler;

    TextView scoreView, timeView, timesupView;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);

        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        screenWidth = size.x; screenHeight = size.y;

        changeTextHandler = new Handler(){
            public void handleMessage(Message msg){
                changeText(scoreView, Integer.toString( (int)( score.getVal() ) ));
                changeText(timeView, Integer.toString( (int)( timeLeft ) ));
            }
        };
        showTextHandler = new Handler(){
            public void handleMessage(Message msg){
                showText(timesupView);
            }
        };

        scoreView = findViewById(R.id.score);
        timeView = findViewById(R.id.time);
        timesupView = findViewById(R.id.timesup);
        progressBar = findViewById(R.id.timeBar);

        score = new CBRdouble(0);
        timeLeft = 60.0;
        needInit = true;
        gameRunning = new CBRboolean(true);
        timeClickCount = new CBRint(0);

        buttons = new ArrayList<>();

        buttons.add(new MovingButton( (ImageButton)findViewById(R.id.Hole1), (ImageButton)findViewById(R.id.Hole), screenWidth, screenHeight, score, gameRunning ) );
        buttons.add(new MovingButton( (ImageButton)findViewById(R.id.Hole2), (ImageButton)findViewById(R.id.Hole), screenWidth, screenHeight, score, gameRunning ) );
        buttons.add(new MovingButton( (ImageButton)findViewById(R.id.Hole3), (ImageButton)findViewById(R.id.Hole), screenWidth, screenHeight, score, gameRunning ) );
        buttons.add(new MovingButton( (ImageButton)findViewById(R.id.Hole4), (ImageButton)findViewById(R.id.Hole), screenWidth, screenHeight, score, gameRunning ) );
        buttons.add(new MovingButton( (ImageButton)findViewById(R.id.Hole5), (ImageButton)findViewById(R.id.Hole), screenWidth, screenHeight, score, gameRunning ) );
        buttons.add(new MovingButton( (ImageButton)findViewById(R.id.Hole6), (ImageButton)findViewById(R.id.Hole), screenWidth, screenHeight, score, gameRunning ) );

        progressBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timeClickCount.addVal(1);
                if (timeClickCount.getVal() >= 20){
                    timeClickCount.setVal(0);
                    timeLeft += 1.0;
                }
            }
        });

        final Timer timeTimer = new Timer();
        final Timer textTimer = new Timer();
        final Timer directionTimer = new Timer();
        final Timer holeTimer = new Timer();

        final TimerTask showText = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Message msg = changeTextHandler.obtainMessage();
                        changeTextHandler.sendMessage(msg);
                    }
                });
            }
        };

        final TimerTask moveHole = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        for (MovingButton button : buttons){
                            if (needInit) button.initXY();
                            button.move();
                        }
                        needInit = false;
                    }
                });
            }
        };

        final TimerTask changeDirection = new TimerTask() {
            @Override
            public void run() {
                for (MovingButton button : buttons){
                    button.angle = Math.random() * 360;
                }
                Log.d("changeDirectionBOJ", "Change Direction");
            }
        };

        final TimerTask timePass = new TimerTask(){
            @Override
            public void run() {
                timeLeft -= 1 / 30.0;
                progressBar.setProgress( (int)( timeLeft  * 1000 ) );
                if (timeLeft < 0){
                    timeTimer.cancel();
                    textTimer.cancel();
                    directionTimer.cancel();
                    holeTimer.cancel();
                    endGame();
                }
                else{
                    for (MovingButton button : buttons){
                        if (button.isMole == false){
                            button.waitTime -= 1 / 30.0;
                            if (button.waitTime <= 0){
                                button.MoleUp();
                            }
                        }
                        else{
                            button.showTime -= 1 / 30.0;
                            if (button.showTime <= 0){
                                button.MoleDown();
                            }
                        }
                    }
                }
            }
        };

        timeTimer.schedule(timePass, 0, 33);
        textTimer.schedule(showText, 0, 33);
        //directionTimer.schedule(changeDirection, 10000, 10000);
        holeTimer.schedule(moveHole, 10000, 33);
    }

    public void endGame(){
        for (MovingButton button : buttons){
            button.MoleDown();
        }
        gameRunning.setVal(false);
        Message msg = showTextHandler.obtainMessage();
        showTextHandler.sendMessage(msg);
    }

    public void changeText(TextView textView, String string){
        textView.setText(string);
    }

    public void showText(TextView textView){
        textView.setVisibility(View.VISIBLE);
    }
}