package com.example.dotheg;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MovingButton {
    ImageButton button, button2;
    double x, y, speed, angle, accel, speedLimit;
    double waitTime, showTime;
    int screenWidth, screenHeight;
    boolean isMole, isMove;
    // CBRint score;
    CBRdouble score;
    CBRboolean gameRunning;

    public MovingButton(ImageButton button, ImageButton button2, int width, int height, final CBRdouble score, final CBRboolean gameRunning){
        this.button = button;
        this.button2 = button2;
        this.screenWidth = width;
        this.screenHeight = height;
        this.score = score;
        this.gameRunning = gameRunning;

        x = y = 0;
        speed = 100.0;
        speedLimit = 500.0;
        angle = Math.random() * 360.0;
        accel = 10.0;
        waitTime = Math.random() * 4 + 1;
        showTime = 0.0;
        isMole = false;
        isMove = false;

        button.setX((float)x);
        button.setY((float)y);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (gameRunning.getVal() == true){
                    if (isMole){
                        if (isMove == false) AddScore( showTime*showTime * accel );
                        else AddScore( showTime*showTime * (accel + speed*speed) );
                        MoleDown();
                    }
                    else{
                        if (isMove == false) AddScore( -5*5 * accel*accel );
                        else AddScore( -5*5 * (accel+speed)*(accel+speed) );
                    }
                    Log.d("MovingButton", score.getVal() + " Click");
                }
            }
        });
    }

    public void initXY(){
        int[] pos = new int[2];
        button.getLocationOnScreen(pos);
        x = pos[0];
        y = pos[1];
    }

    public void AddScore(double score){
        this.score.addVal(score);
        // Log.d("AddScore", "!!!!!Score = " + this.score.getVal());
    }

    public void MoleUp(){
        button.setImageResource(R.drawable.holemole);
        isMole = true;
        showTime = 2.0;
    }

    public void MoleDown(){
        button.setImageResource(R.drawable.hole);
        isMole = false;
        waitTime = Math.random() * 4 + 1;
    }

    public boolean collideX(){ return 0 > x || x + button.getWidth() > screenWidth; }
    public boolean collideY(){ return 0 > y + button.getHeight() - button2.getHeight() || y + button.getHeight() > screenHeight; }

    public void move(){
        isMove = true;
        x += Math.cos( angle * Math.PI / 180 ) * speed / 30.0;
        y += Math.sin( angle * Math.PI / 180 ) * speed / 30.0;
        if (this.collideX()){
            x -= Math.cos( angle * Math.PI / 180 ) * speed / 30.0;
            angle = 180 - angle;
            if (angle < 0) angle += 360;
            x += Math.cos( angle * Math.PI / 180 ) * speed / 30.0;
        }
        if (this.collideY()){
            y -= Math.sin( angle * Math.PI / 180 ) * speed / 30.0;
            angle = 360 - angle;
            y += Math.sin( angle * Math.PI / 180 ) * speed / 30.0;
        }
        button.setX((float)x);
        button.setY((float)y);
        speed += accel / 30.0;
        if (speed > speedLimit) speed = speedLimit;
    }
}
